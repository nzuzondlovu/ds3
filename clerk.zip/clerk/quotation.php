<?php
include 'functions.php';
?>

<?php
if(isset($_SESSION['key']) == '' ) {
    header("location:../login.php");
}
?>

<?php

if(isset($_POST['submit'])) {
 
    $device_name = mysqli_real_escape_string($con, strip_tags(trim($_POST["device_name"])));
    $Serial_no = mysqli_real_escape_string($con, strip_tags(trim($_POST["serial_no"])));
    $model = mysqli_real_escape_string($con, strip_tags(trim($_POST["model"])));
    $Accessory = mysqli_real_escape_string($con, strip_tags(trim($_POST["accessory"])));
    $technician = mysqli_real_escape_string($con, strip_tags(trim($_POST["technician"])));
     $description = mysqli_real_escape_string($con, strip_tags(trim($_POST["desc"])));
     $deposit = '';
     $balance = '';
     $Total = '';
    
    if($device_name != '' && $Serial_no != '' && $model != '' && $Accessory != '' && $technician != '' && $description ) {

        $sql = "INSERT INTO quotation(device_name, serial_no,model,Accessory,technician,description,,deposit,balance,total)
        VALUES('".$device_name."','".$Serial_no."' , '".$model."', '".$Accessory."', '".$technician."', '".$description."',, '".$deposit."', '".$balance."', '".$Total."')";
        mysqli_query($con, $sql);
        $_SESSION['success'] = 'Your new Quotation is added successfully.';
        header("Location: viewquot.php");
    }
	else {
        $_SESSION['failure'] = 'Please fill in all fields.';
    }
}
?>

<?php
include 'header.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add Quotation</h1>
			</div>
			<!-- /.col-lg-12 -->
		</div>
		<!-- /.row -->
		<!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <?php if(isset($_SESSION['failure']) && $_SESSION['failure'] != '') { ?>
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo $_SESSION['failure']; unset($_SESSION['failure']); ?>
                    </div>
                    <?php } ?>

                    <?php if(isset($_SESSION['success']) && $_SESSION['success'] != '') { ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                    <?php } ?>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Enter Quotation Details
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-offset-3 col-md-6">
                                <form role="form" method="post">
                                    <div class="form-group">
                                        <label>Device Name</label>
                                        <input name="device_name" class="form-control" placeholder="Enter text">
                                    </div>
                                    <div class="form-group">
                                        <label>Serial Number</label>
                                        <input name="serial_no" class="form-control" placeholder="Enter text">
                                    </div>
                                    <div class="form-group">
                                        <label>Model</label>
                                        <input name="model" class="form-control" placeholder="Enter text">
                                    </div>
                                    <div class="form-group">
                                        <label>Accessorry</label>
                                        <input type="checkbox" name="accessory" value="charger">Charger</input>
                                        <input type="checkbox" name="accessory" value="cable">Cable</input>
                                        <input type="checkbox" name="accessory" value="adapter">Adapter</input>
                                        <input type="checkbox" name="accessory" value="battery">Battery</input>
                                        <input type="checkbox" name="accessory" value="mouse">Mouse</input>
                                        <input type="checkbox" name="accessory" value="keyboard">Keyboard</input>
                                    </div>
                                    <div class="form-group">
                                    <label>Technician</label>
                                        <select name="technician" class="form-control">
                                            <option value="" selected="selected">Select type</option>
                                            <?php
                                            $sql = "SELECT * FROM technician ORDER BY TName ASC";
                                            $res = mysqli_query($con, $sql);

                                            if(mysqli_num_rows($res) > 0) {
                                                while($row = mysqli_fetch_assoc($res)) {
                                                    echo '<option value="'.$row['TName'].'">'.$row['TName'].'</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="desc" class="form-control" rows="3"></textarea>
                                    </div>
    
                                    
                                    <button name="submit" type="submit" class="btn btn-primary">Submit Quotation</button>
                                    <button type="reset" class="btn btn-default">Reset Quotation</button>
                                </form>
                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php
include 'footer.php';
?>