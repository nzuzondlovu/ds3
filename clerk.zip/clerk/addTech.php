<?php
include 'functions.php';
?>

<?php
if(isset($_SESSION['key']) == '' ) {
    header("location:../login.php");
}
?>

<?php

if(isset($_POST['submit'])) {

    $name = mysqli_real_escape_string($con, strip_tags(trim($_POST["name"])));
    $surname = mysqli_real_escape_string($con, strip_tags(trim($_POST["surname"])));
    $email = mysqli_real_escape_string($con, strip_tags(trim($_POST["email"])));
    $specialty= mysqli_real_escape_string($con, strip_tags(trim($_POST["specialty"])));


    
     if($name != '' && $surname != '' && $email != ''&& $specialty != '') {
     
	 $sql = "INSERT INTO technician(TName,surname,email,specialty)
        VALUES( '".$name."','".$surname."','".$email."','".$specialty."')";
        mysqli_query($con, $sql);
        $_SESSION['success'] = 'Your new technician was added successfully.';
        header("Location: viewtech.php");
    }else {
        $_SESSION['failure'] = 'Please fill in all fields.';
    }
   

}
?>

<?php
include 'header.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add Technician</h1>
			</div>
			<!-- /.col-lg-12 -->
		</div>
		<!-- /.row -->
		<!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <?php if(isset($_SESSION['failure']) && $_SESSION['failure'] != '') { ?>
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo $_SESSION['failure']; unset($_SESSION['failure']); ?>
                    </div>
                    <?php } ?>

                    <?php if(isset($_SESSION['success']) && $_SESSION['success'] != '') { ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                    <?php } ?>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Enter Technician details
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-offset-3 col-md-6">
                                <form role="form" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label>Technian name</label>
                                        <input name="name" class="form-control" placeholder="Enter text">
                                    </div>
                                    <div class="form-group">
                                        <label>Technician Surname</label>
                                         <input name="surname" class="form-control" placeholder="Enter text">
                                    </div>
                                    <div class="form-group">
                                        <label>Email Address</label>
                                         <input name="email" class="form-control" placeholder="Enter text">
                                    </div>
                                    <div class="form-group">
                                    <label>Specialty</label>
                                        <select name="specialty" class="form-control">
                                            <option value="" selected="selected">Select type</option>
                                            <option value="Hardware" >Hardware Technician</option>
                                            <option value="Software" >Software Technician</option>
                                            <option value="Both" > Hardware & Software Technician</option>
                                        </select>
                                        
                                    </div>
                                   
                                    <button name="submit" type="submit" class="btn btn-primary">Submit Technician</button>
                                    <button type="reset" class="btn btn-default">Reset Technician</button>
                                </form>
                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php
include 'footer.php';
?>