<?php
ob_start();
include 'functions.php';
?>

<?php
include 'header.php';
?>


<?php
include 'footer.php';
?>