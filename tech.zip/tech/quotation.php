<?php
include 'functions.php';
?>

<?php
if(isset($_SESSION['key']) == '' ) {
    header("location:../login.php");
}
?>

<?php

if(isset($_POST['submit'])) {

$description = mysqli_real_escape_string($con, strip_tags(trim($_POST["desc"])));
     $deposit = mysqli_real_escape_string($con, strip_tags(trim($_POST["deposit"])));
     $balance = mysqli_real_escape_string($con, strip_tags(trim($_POST["balance"])));
     $Total = mysqli_real_escape_string($con, strip_tags(trim($_POST["total"])));
      $status = mysqli_real_escape_string($con, strip_tags(trim($_POST["status"])));
     
    if( $deposit != '' && $balance != '' && $total != '' && $description != '' && $status != '') {

     $sql = "UPDATE quotation SET description='".$description."', deposit='".$deposit."',balance='".$balance."',total='".$Total."',Status='".$status."' WHERE id='".$id."'";
        mysqli_query($con, $sql);
        $_SESSION['success'] = 'Your new Quotation is added successfully.';
        header("Location: viewquot.php");
    }else {
        $_SESSION['failure'] = 'Please fill in all fields.';
    }
}
?>

<?php
include 'header.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add Quotation</h1>
			</div>
			<!-- /.col-lg-12 -->
		</div>
		<!-- /.row -->
		<!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <?php if(isset($_SESSION['failure']) && $_SESSION['failure'] != '') { ?>
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo $_SESSION['failure']; unset($_SESSION['failure']); ?>
                    </div>
                    <?php } ?>

                    <?php if(isset($_SESSION['success']) && $_SESSION['success'] != '') { ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                    <?php } ?>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Enter Quotation Details
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-offset-3 col-md-6">
                                <form role="form" method="post">
                                    <div class="form-group">
                                        <label>Device Name</label>
                                         <input class="form-control" value="<?php
                                        $res = mysqli_query($con, "SELECT * FROM quotation WHERE id='".$id."' ");
                                        $row = mysqli_fetch_assoc($res);
                                        echo $row['device_no'];
                                        ?> " disabled="">
                                    </div>
                                    <div class="form-group">
                                    
                                        <label>Serial Number</label>
                                        <input class="form-control" value="<?php
                                        $res = mysqli_query($con, "SELECT * FROM quotation WHERE id='".$_SESSION['user_id']."' ");
                                        $row = mysqli_fetch_assoc($res);
                                        echo $row['serial_no'];
                                        ?> " disabled="">
                                    </div>
                                    <div class="form-group">
                                        <label>Model</label>
                                        <input class="form-control" value="<?php
                                        $res = mysqli_query($con, "SELECT * FROM quotation WHERE id='".$_SESSION['user_id']."' ");
                                        $row = mysqli_fetch_assoc($res);
                                        echo $row['model'];
                                        ?> " disabled="">
                                    </div>
                                    <div class="form-group">
                                        <label>Accessorry</label>
                                         <input class="form-control" value="<?php
                                        $res = mysqli_query($con, "SELECT * FROM quotation WHERE id='".$_SESSION['user_id']."' ");
                                        $row = mysqli_fetch_assoc($res);
                                        echo $row['Accessory'];
                                        ?> " disabled="">
                                    </div>
                                    <div class="form-group">
                                    <label>Technician</label>
                                         <input class="form-control" value="<?php
                                        $res = mysqli_query($con, "SELECT * FROM quotation WHERE id='".$_SESSION['user_id']."' ");
                                        $row = mysqli_fetch_assoc($res);
                                        echo $row['technician'];
                                        ?> " disabled="">
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="desc" class="form-control" rows="3"></textarea>
                                    </div>
                                     <div class="form-group">
                                        <label>Deposit</label>
                                        <input name="deposit" class="form-control" placeholder="Enter text">
                                    </div>
                                     <div class="form-group">
                                        <label>Balance</label>
                                        <input name="balance" class="form-control" placeholder="Enter text">
                                    </div>
                                     <div class="form-group">
                                        <label>Total</label>
                                        <input name="total" class="form-control" placeholder="Enter text">
                                    </div>
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select name="status" class="form-control">
                                            <option value="" selected="selected">Select type</option>
                                            <?php
                                            $sql = "SELECT * FROM status ORDER BY name ASC";
                                            $res = mysqli_query($con, $sql);

                                            if(mysqli_num_rows($res) > 0) {
                                                while($row = mysqli_fetch_assoc($res)) {
                                                    echo '<option value="'.$row['name'].'">'.$row['name'].'</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                     
                                    
                                    <button name="submit" type="submit" class="btn btn-primary">Submit Quotation</button>
                                    <button type="reset" class="btn btn-default">Reset Quotation</button>
                                </form>
                            </div>
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php
include 'footer.php';
?>